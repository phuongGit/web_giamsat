window.$ = window.jQuery = require('jquery');
window.io = require('socket.io-client');
require('bootstrap-sass');
require('bootstrap-toggle');
require('../node_modules/font-awesome/scss/font-awesome.scss');
require('../node_modules/spectrum-colorpicker/spectrum.js');
